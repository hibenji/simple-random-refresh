// time to reload each website
chrome.alarms.clearAll();
chrome.storage.local.clear();
chrome.storage.sync.clear();

var reload_time = 20;


// get timestamp in seconds
var timestamp = Math.floor(Date.now() / 1000);


chrome.cookies.set({
  url: 'https://core.arc.io',
  domain: ".arc.io",
  expirationDate: 1706901842,
  name: "widgetOptState",
  value: '{%22state%22:%22OPTED_IN%22%2C%22date%22:'+ timestamp + '%2C%22referrerPropertyId%22:%22CMsyZo2Y%22%2C%22referrerOrigin%22:%22https://benji.link%22}',
  sameSite: 'no_restriction',
  secure: true

}, function(cookie) {
console.log("Cookie set: " + cookie);
});


// set i to local storage
var i = 0;
chrome.storage.local.set({'i': i}, function() {
  console.log('Value is set to ' + i);
});

// function
function get() {
  chrome.tabs.query({}, function(tabs) { 

    // get i
    chrome.storage.local.get(['i'], function(result) {
      i = result.i;
      console.log('Value currently is ' + i);

      if (i < tabs.length - 1) {
        chrome.storage.local.set({'i': i+1}, function() {
          console.log("i increased to " + (i+1));
        });
      } else {
        chrome.storage.local.set({'i': 0}, function() {
          console.log("i reset to " + 0);
        });
      }
    

      console.log("i = " + i);
      // console.log(tabs);
      var tab = tabs[i];



      // console.log(tab.url)
      chrome.tabs.reload(tab.id);

      const d = new Date();
      let minutes = d.getMinutes();
      let hours = d.getHours();

      let time = hours + ":" + minutes;

      // clear all alarms
      chrome.alarms.clearAll();

      // time to reload each website
      var actual_time = reload_time / (tabs.length - 1);
      console.log("time = " + actual_time);
      // actual time in ms
      actual_time = actual_time * 60 * 1000;

      console.log(Date.now() + actual_time)

      // send get request to api.benji.link/arc using fetch() with the tab.url and time as parameters

      url = 'https://api.benji.link/arc?url='+tab.url + '&time=' + time + '&i=' + i;

      fetch(url, {
        method: 'GET',
        mode: 'no-cors',
        headers: {
          'Content-Type': 'application/json'
        }
      }).then(function(response) {
        console.log(response);
      }).catch(function(error) {
        console.log(error);
      });

      chrome.alarms.create("reload", {when: Date.now() + actual_time});


  });
    
  });
}


get();

// listen for alarm
chrome.alarms.onAlarm.addListener(function(alarm) {
  console.log("alarm");
  get();
});